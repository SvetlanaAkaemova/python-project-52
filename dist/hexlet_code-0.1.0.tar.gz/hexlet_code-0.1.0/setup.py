# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['task_manager']

package_data = \
{'': ['*'], 'task_manager': ['templates/*']}

install_requires = \
['django>=4.1.7,<5.0.0',
 'gunicorn>=20.1.0,<21.0.0',
 'python-dotenv>=1.0.0,<2.0.0']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/SvetlanaAkaemova/python-project-52/workflows/hexlet-check/badge.svg)](https://github.com/SvetlanaAkaemova/python-project-52/actions)',
    'author': 'svetlana_akaemova',
    'author_email': 'akaemova.sv@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
